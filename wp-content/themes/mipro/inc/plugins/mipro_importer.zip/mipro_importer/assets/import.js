(function($) {
    "use strict";

    $('#mipro-importer .nav-tab-wrapper a').on('click', function(e) {
        var clicked = $(this).attr('href');
        if (clicked.indexOf('#') == -1) {
            return true;
        }
        $('#mipro-importer .nav-tab-wrapper a').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active').blur();
        $('.group').hide();
        $(clicked).fadeIn();
        e.preventDefault();
    });

    $('#mipro-importer .option label').on('click', function() {
        var checkbox = $(this).find('input[type="checkbox"]');
        if (checkbox.is(':checked')) {
            $(this).addClass('is-checked');
        } else {
            $(this).removeClass('is-checked');
        }

        mipro_import_button();
    });

    function mipro_import_button() {
        var disabled = true;
        $('#mipro-importer .option input[type="checkbox"]').each(function() {
            if ($(this).is(':checked')) {
                disabled = false;
                return;
            }
        });
        $('#mipro-import-button').attr('disabled', disabled);
    }

    $('#mipro-import-button').on('click', function() {
        $('#mipro-importer .loading').show();
        var options = {
            theme_options: $('#mipro_import_theme_options').is(':checked'),
            widgets: $('#mipro_import_widget').is(':checked'),
            revsliders: $('#mipro_import_revslider').is(':checked'),
            demo_content: $('#mipro_import_demo_content').is(':checked')
        };

        mipro_import_options(options);
    });

    function mipro_import_options(options) {
        if (options.theme_options) {
            var data = { 'action': 'mipro_import_theme_options' };

            $.post(ajaxurl, data, function(response) {
                mipro_import_message('Import Theme Options sucessfully.');
                mipro_import_widgets(options);
            }).fail(function(response) {
                mipro_import_widgets(options);
            });
        } else {
            mipro_import_widgets(options);
        }
    }

    function mipro_import_widgets(options) {
        if (options.widgets) {
            var data = { 'action': 'mipro_import_widget' };

            $.post(ajaxurl, data, function(response) {
                mipro_import_message('Import Widgets sucessfully.');
                mipro_import_revsliders(options);
            }).fail(function(response) {
                mipro_import_revsliders(options);
            });
        } else {
            mipro_import_revsliders(options);
        }
    }

    function mipro_import_revsliders(options) {
        if (options.revsliders) {
            var data = { 'action': 'mipro_import_revslider' };

            $.post(ajaxurl, data, function(response) {
                mipro_import_message('Import Revolution slider sucessfully.');
                mipro_import_content(options);
            }).fail(function(response) {
                mipro_import_content(options);
            });
        } else {
            mipro_import_content(options);
        }
    }

    function mipro_import_content(options) {
        if (options.demo_content) {
            var data = { 'action': 'mipro_import_content' };

            $.post(ajaxurl, data, function(response) {
                mipro_import_message('Import Demo Content sucessfully.');
                mipro_import_config(options);
            }).fail(function(response) {
                mipro_import_message('Import Demo Content Fail!');
            });
        } else {
            mipro_import_finish();
        }
    }

    function mipro_import_config(options) {
        if (options.demo_content) {
            var data = { 'action': 'mipro_import_config' };

            $.post(ajaxurl, data, function(response) {
                mipro_import_finish();
            }).fail(function(response) {
                mipro_import_finish();
            });
        } else {
            mipro_import_finish();
        }
    }

    function mipro_import_finish() {
        $('#mipro-importer .loading').hide();
        mipro_import_message('Success!!!');
    }

    function mipro_import_message(message) {
        var message_wrapper = $('#mipro-importer .messages');
        message_wrapper.append('<p>' + message + '</p>');
    }

})(jQuery);